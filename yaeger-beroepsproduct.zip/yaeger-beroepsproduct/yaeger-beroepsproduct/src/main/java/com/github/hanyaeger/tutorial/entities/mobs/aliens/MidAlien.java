package com.github.hanyaeger.tutorial.entities.mobs.aliens;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;

import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MidAlien extends Alien {
    private Aliens aliens;
    private boolean isShooting;

    public MidAlien(Coordinate2D initialLocation, Aliens aliens, boolean isShooting) {
        super(initialLocation, false, "sprites/alien1_50.png");
        this.health = 200;
        this.score = 10;
        this.aliens = aliens;
        this.isShooting = isShooting;
        shoot();
    }

    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {
        switch (sceneBorder){
            case LEFT:
                aliens.changeMotion(sceneBorder, "Right");
                break;
            case RIGHT:
                aliens.changeMotion(sceneBorder, "Left");
                break;
            case BOTTOM:
                aliens.bottomReached();
                break;
        }
    }
    static Timer timer = new Timer();
    static class Task extends TimerTask {
        @Override
        public void run() {
            int delay = (5 + new Random().nextInt(5)) * 1000;
            timer.schedule(new Task(), delay);

        }

    }

    public void shoot(){
        if(isShooting == true){
            System.out.println("Ik schiet");
            new Task().run();
        }
    }
}
