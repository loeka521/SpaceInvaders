package com.github.hanyaeger.tutorial.bullets;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.Collider;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.scenes.GameScene;

public class RegularBullet extends Bullet{
    private Aliens aliens;
    public RegularBullet(Coordinate2D initialLocation, double direction, GameScene gameScene, Aliens aliens) {
        super(initialLocation, direction, gameScene, aliens);
        this.aliens = aliens;
        damage = 100;
    }
}
