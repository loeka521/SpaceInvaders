package com.github.hanyaeger.tutorial.entities.mobs.aliens;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;

public class TopAlien extends Alien {
    private Aliens aliens;
    private boolean isShooting;

    public TopAlien(Coordinate2D initialLocation, Aliens aliens, boolean isShooting) {
        super(initialLocation, false, "sprites/alien2_50.png");
        this.health = 300;
        this.score = 20;
        this.aliens = aliens;
        this.isShooting = isShooting;
    }

    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {
        switch (sceneBorder){
            case LEFT:
                aliens.changeMotion(sceneBorder, "Right");
                break;
            case RIGHT:
                aliens.changeMotion(sceneBorder, "Left");
                break;
            case BOTTOM:
                aliens.bottomReached();
                break;
        }
    }
    public void shoot(){
        if(isShooting == true){
            System.out.println("Ik schiet");
        }
    }
}
