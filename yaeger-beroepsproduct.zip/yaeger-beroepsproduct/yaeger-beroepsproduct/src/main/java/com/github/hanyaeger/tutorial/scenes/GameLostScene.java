package com.github.hanyaeger.tutorial.scenes;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.StaticScene;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.entities.buttons.TitleSceneButton;
import com.github.hanyaeger.tutorial.entities.scoretext.ScoreText;

public class GameLostScene extends StaticScene {
    private SpaceInvaders spaceInvaders;

    public GameLostScene(SpaceInvaders spaceInvaders){
        this.spaceInvaders = spaceInvaders;
    }

    @Override
    public void setupScene() {
        setBackgroundImage("backgrounds/ScreenshotStarfield.png");
    }

    @Override
    public void setupEntities() {
        var gameWonText = new ScoreText(new Coordinate2D(getWidth() / 2 - 200, getHeight() / 8), this.spaceInvaders, "Game lost, better luck next time!");
        addEntity(gameWonText);


        var goBackButton = new TitleSceneButton(new Coordinate2D(getWidth() / 2 - 50, getHeight() / 3), this.spaceInvaders, "Go Back", "goBack ");
        addEntity(goBackButton);
    }
}