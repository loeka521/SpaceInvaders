package com.github.hanyaeger.tutorial;

public class Empty {
}
